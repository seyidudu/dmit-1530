$(".menu-btn").click(function(e){
    $("nav").toggle();
    e.preventDefault();

})
